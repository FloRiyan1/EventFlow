@echo off
title EventFlow (Lokal)
if exist "EventFlow.exe" (
    start "" "EventFlow.exe"
    exit /b
)
if exist "server.js" (
    start http://localhost:3000/eventFlow/
    node server.js
    pause
    exit /b
)
echo FEHLER: EventFlow.exe wurde nicht gefunden!
pause

#!/bin/bash
echo "===================================================="
echo "  EventFlow wird gestartet..."
echo "===================================================="
(sleep 1 && (open http://localhost:3000/eventFlow/ 2>/dev/null || xdg-open http://localhost:3000/eventFlow/ 2>/dev/null)) &
node server.js
